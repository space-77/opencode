---
name: "word-template-formatter"
description: "将任意 Word 文档转换为指定模板格式的 Word 文档，保留模板样式和结构。当用户需要格式化 Word 文档、应用模板样式、或转换文档格式时调用此 skill。"
---

# Word Template Formatter

将任意 Word 文档通过 pandoc JSON 中转，严格转换为模板格式的 Word 文档，保留模板的所有样式和结构。

## 核心流程

```
源文档(docx) → pandoc → JSON → 按模板样式重构 → 输出文档(docx)
```

通过 pandoc 的 JSON 中间格式提取文档结构（标题、段落、表格、图片、列表），然后按模板样式重新生成 Word 文档，确保格式与模板完全一致。

## 核心能力

### 1. 模板结构保留
- 封面节、目录节、图目录节、表目录节、正文节（5 节结构完整保留）

### 2. 样式自动映射
| 源文档内容 | 识别方式 | 目标模板样式 |
|---|---|---|
| 一级标题 | Heading 1 | Heading 1 |
| 二级标题 | Heading 2 | Heading 2 |
| 三级标题 | Heading 3 | Heading 3 |
| 四级标题 | Heading 4 | Heading 4 |
| 五级标题 | Heading 5 | Heading 5 |
| 正文段落 | Normal | Normal（1.5倍行距，首行缩进）|
| 图片段落 | Image | 图（含 Caption 题注）|
| 表格 | Table | Table Grid（autofit 自适应宽度）|
| 图题注 | 图 X-Y xxx | Caption + 章节编号（如 图 3-1）|
| 表题注 | 表 X-Y xxx | Caption + 章节编号（如 表 2-1）|
| 列表 | BulletList / OrderedList | List Bullet / List Number |

### 3. TOC 域自动生成
- 目录、图目录、表目录均插入 Word 可更新 TOC 域（按 F9 更新）

### 4. 封面与页眉页脚
- 模板封面结构保留，项目名称从源文档自动提取并替换（保留模板格式）
- 各节页眉页脚与模板一致（公开/正本标记等）

### 5. 智能清理与解析
- 正文区域自动删除空行，封面区域保留空行用于排版
- 支持相对路径和绝对路径的图片引用

## 使用方法

```bash
python3 scripts/md_bridge.py --source <源文件.docx> --template <模板文件.docx> --output <输出文件.docx>
```

### 参数说明

| 参数 | 简写 | 说明 |
|---|---|---|
| `--source` | `-s` | 源文档路径（需要转换的 .docx 文件）|
| `--template` | `-t` | 模板文档路径（包含目标格式的 .docx 文件）|
| `--output` | `-o` | 输出文档路径 |

## 模板要求

默认模板文件路径：`assets/template.docx`

如需更换模板，将新模板复制到该路径即可。模板应包含：
- **封面节**：响应文件、项目名称、编号等
- **目录节**：标题 + TOC 占位
- **图目录节**：标题 + TOC 占位
- **表目录节**：标题 + TOC 占位
- **正文节**：页眉含 "标题1" 等

## 注意事项

1. **目录更新**：输出文档在 Word 中打开后，全选并按 `F9` 更新所有域（目录、图目录、表目录、题注编号）
2. **pandoc 依赖**：需要系统安装 pandoc（`apt install pandoc` 或 `brew install pandoc`）
3. **公式处理**：源文档中的公式会被转换为 LaTeX 占位符，需手动替换为 OMML 公式
4. **字体兼容性**：模板使用 Times New Roman + 宋体，确保系统已安装这些字体
5. **python-docx 限制**：某些复杂的 Word 特性（如 VBA 宏、ActiveX 控件）可能无法保留

## 依赖安装

```bash
# 安装 pandoc（系统级）
apt install pandoc   # Linux
brew install pandoc  # macOS

# 安装 Python 依赖
pip install python-docx lxml
```

**依赖列表**：
- `pandoc`（系统级）
- `python-docx`
- `lxml`
