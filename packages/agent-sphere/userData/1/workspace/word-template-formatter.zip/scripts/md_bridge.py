#!/usr/bin/env python3
"""
Word → JSON (via pandoc) → Word  中转方案
将 Word 文档通过 pandoc 的 JSON 中间格式转换，保留结构、图片、表格、列表，
然后按模板格式生成新的 Word 文档。

核心流程：
  1. 用 pandoc 将 docx 转为 JSON（提取图片到 media/ 目录）
  2. 解析 JSON 结构（Header/Para/Table/BulletList/OrderedList/Image/Math）
  3. 用模板创建新 docx，按 JSON 结构填充内容，应用模板样式

用法：
  python3 md_bridge.py --source <源文件.docx> --template <模板文件.docx> --output <输出文件.docx>
"""

import argparse
import copy
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from typing import List, Tuple, Optional, Dict, Any

from docx import Document
from docx.shared import Cm, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml, OxmlElement


# ────────────────────────────────────────────────────────────────────────────
# 1. 通用辅助
# ────────────────────────────────────────────────────────────────────────────

def _run_cmd(cmd: List[str], cwd: Optional[str] = None) -> Tuple[int, str, str]:
    result = subprocess.run(cmd, capture_output=True, text=True, cwd=cwd)
    return result.returncode, result.stdout, result.stderr


def _get_tag_local_name(tag: str) -> str:
    if '}' in tag:
        return tag.split('}')[-1]
    if ':' in tag:
        return tag.split(':')[-1]
    return tag


# ────────────────────────────────────────────────────────────────────────────
# 2. Pandoc 转换：docx → JSON
# ────────────────────────────────────────────────────────────────────────────

def docx_to_json(source_path: str, work_dir: str) -> Tuple[str, str, Dict]:
    """
    用 pandoc 将 docx 转为 JSON，提取图片到 media/ 目录。
    返回 (json_path, media_dir, json_data)。
    """
    json_path = os.path.join(work_dir, "content.json")
    media_dir = os.path.join(work_dir, "media")
    
    cmd = [
        "pandoc",
        source_path,
        "-t", "json",
        "--extract-media", media_dir,
        "-o", json_path,
    ]
    
    rc, stdout, stderr = _run_cmd(cmd)
    if rc != 0:
        raise RuntimeError(f"pandoc docx→json 失败: {stderr}")
    
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    print(f"✅ pandoc 转换完成: {json_path}")
    print(f"   图片目录: {media_dir}")
    return json_path, media_dir, data


# ────────────────────────────────────────────────────────────────────────────
# 3. JSON 解析：提取文本、图片、表格结构
# ────────────────────────────────────────────────────────────────────────────

def inlines_to_text(inlines: List[Dict]) -> str:
    """从 pandoc inline 列表中提取纯文本。"""
    parts = []
    for inline in inlines:
        t = inline.get('t')
        c = inline.get('c')
        if t == 'Str':
            parts.append(c)
        elif t == 'Space':
            parts.append(' ')
        elif t == 'SoftBreak':
            parts.append('\n')
        elif t == 'LineBreak':
            parts.append('\n')
        elif t in ('Strong', 'Emph', 'Underline', 'Strikeout'):
            parts.append(inlines_to_text(c))
        elif t == 'Superscript':
            parts.append(inlines_to_text(c))
        elif t == 'Subscript':
            parts.append(inlines_to_text(c))
        elif t == 'Link':
            # c = [[attr], [inlines], [url, title]]
            if len(c) >= 3:
                parts.append(inlines_to_text(c[1]))
        elif t == 'Code':
            # c = [[attr], code]
            if len(c) >= 2:
                parts.append(c[1])
        elif t == 'Math':
            # c = [[math_type], latex]
            if len(c) >= 2:
                parts.append(f"${c[1]}$")
        elif t == 'Image':
            # c = [[attr], [alt_text], [url, title]]
            if len(c) >= 3:
                parts.append(f"[图片: {c[1][0] if c[1] else ''}]")
        elif t == 'RawInline':
            # c = [format, text]
            if len(c) >= 2:
                parts.append(c[1])
    return ''.join(parts)


def inlines_to_runs(para, inlines: List[Dict], source_doc=None, target_doc_ref=None):
    """将 pandoc inline 列表转换为 docx runs，保留格式。"""
    for inline in inlines:
        t = inline.get('t')
        c = inline.get('c')
        
        if t == 'Str':
            para.add_run(c)
        elif t == 'Space':
            if para.runs:
                para.runs[-1].text += ' '
            else:
                para.add_run(' ')
        elif t == 'SoftBreak' or t == 'LineBreak':
            para.add_run('\n')
        elif t == 'Strong':
            run = para.add_run(inlines_to_text(c))
            run.bold = True
        elif t == 'Emph':
            run = para.add_run(inlines_to_text(c))
            run.italic = True
        elif t == 'Underline':
            run = para.add_run(inlines_to_text(c))
            run.underline = True
        elif t == 'Strikeout':
            run = para.add_run(inlines_to_text(c))
            run.font.strike = True
        elif t == 'Superscript':
            run = para.add_run(inlines_to_text(c))
            run.font.superscript = True
        elif t == 'Subscript':
            run = para.add_run(inlines_to_text(c))
            run.font.subscript = True
        elif t == 'Link':
            if len(c) >= 3:
                # 保留链接文本，忽略 URL
                inlines_to_runs(para, c[1], source_doc, target_doc_ref)
        elif t == 'Code':
            if len(c) >= 2:
                run = para.add_run(c[1])
                run.font.name = 'Courier New'
        elif t == 'Math':
            if len(c) >= 2:
                math_type = c[0][0] if c[0] else 'InlineMath'
                latex = c[1]
                # 尝试用 pandoc 将 LaTeX 转换为 OMML 并插入
                omml_xml = latex_to_omml_xml(latex, math_type)
                if omml_xml:
                    try:
                        from lxml import etree
                        omml_element = etree.fromstring(omml_xml)
                        para._r.append(omml_element)
                    except Exception:
                        # 回退：纯文本占位符
                        run = para.add_run(f"{'$$' if math_type == 'DisplayMath' else '$'}{latex}{'$$' if math_type == 'DisplayMath' else '$'}")
                        run.italic = True
                else:
                    # 回退：纯文本占位符
                    run = para.add_run(f"{'$$' if math_type == 'DisplayMath' else '$'}{latex}{'$$' if math_type == 'DisplayMath' else '$'}")
                    run.italic = True
        elif t == 'Image':
            # 图片需要单独处理（作为段落级元素）
            # inline 图片暂时忽略，会在 block 级别处理
            pass
        elif t == 'RawInline':
            if len(c) >= 2:
                para.add_run(c[1])


def clean_heading_number(text: str) -> str:
    """清理标题中的中文/阿拉伯编号前缀。"""
    if not text:
        return text
    patterns = [
        r'^[（(][一二三四五六七八九十百]+[）)]\s*',          # （一）(一)
        r'^[一二三四五六七八九十百]+[\.、．\s]+',               # 一. 二、
        r'^[第][一二三四五六七八九十百]+[章节]\s*',             # 第一章
        r'^[（(]\d+[）)]\s*',                                  # （1）(1)
        r'^\d+\.\d+\.\d+\.\d+\.\d+\.\d+\.\d+\.\d+\s*',        # 1.1.1.1.1.1.1.1
        r'^\d+\.\d+\.\d+\.\d+\.\d+\.\d+\.\d+\s*',              # 1.1.1.1.1.1.1
        r'^\d+\.\d+\.\d+\.\d+\.\d+\.\d+\s*',                    # 1.1.1.1.1.1
        r'^\d+\.\d+\.\d+\.\d+\.\d+\s*',                         # 1.1.1.1.1
        r'^\d+\.\d+\.\d+\.\d+\s*',                              # 1.1.1.1
        r'^\d+\.\d+\.\d+\s*',                                    # 1.1.1
        r'^\d+\.\d+\s*',                                          # 1.1
        r'^\d+[\.、．]\s*',                                      # 1. 或 1、
        r'^\d+\s+',                                                # 纯数字+空格
    ]
    original = text
    changed = True
    while changed:
        changed = False
        for pattern in patterns:
            new_text = re.sub(pattern, '', text)
            if new_text != text:
                text = new_text
                changed = True
                break
    result = text.strip()
    return result if result else original


def extract_image_info(inlines: List[Dict]) -> List[Tuple[str, str, Any, Any]]:
    """从 inline 列表中提取所有图片信息，返回 (alt_text, url, width, height) 列表。
    width/height 为 docx.shared.Length 对象或 None。
    """
    images = []
    for inline in inlines:
        t = inline.get('t')
        c = inline.get('c')
        if t == 'Image':
            # c = [[attr], [alt_inlines], [url, title]]
            if len(c) >= 3:
                alt = inlines_to_text(c[1]) if c[1] else ''
                url = c[2][0] if c[2] else ''
                width = None
                height = None
                if len(c) >= 1 and isinstance(c[0], list) and len(c[0]) >= 3:
                    attrs = c[0][2]  # [(String, String)] list
                    for key, val in attrs:
                        if key == 'width':
                            width = parse_length(val)
                        elif key == 'height':
                            height = parse_length(val)
                images.append((alt, url, width, height))
        elif t in ('Strong', 'Emph', 'Underline', 'Strikeout', 'Superscript', 'Subscript', 'Link'):
            images.extend(extract_image_info(c[1] if t == 'Link' and len(c) >= 3 else c))
    return images


def is_toc_block(block: Dict) -> bool:
    """检测 pandoc block 是否为目录/TOC 内容。"""
    t = block.get('t')
    c = block.get('c')
    
    # BlockQuote 包含目录链接
    if t == 'BlockQuote':
        return _check_toc_in_blocks(c)
    
    # Para 或 Plain 包含 \l 链接
    if t == 'Para' or t == 'Plain':
        for inline in c if isinstance(c, list) else []:
            if inline.get('t') == 'Link':
                link_c = inline.get('c', [])
                if len(link_c) >= 3:
                    url = link_c[2][0] if link_c[2] else ''
                    if url == r'\l' or '_Toc' in url:
                        return True
    
    return False


def _check_toc_in_blocks(blocks):
    """递归检查 block 列表中是否包含目录链接。"""
    for block in blocks if isinstance(blocks, list) else []:
        t = block.get('t')
        c = block.get('c')
        if t == 'Para' or t == 'Plain':
            for inline in c if isinstance(c, list) else []:
                if inline.get('t') == 'Link':
                    link_c = inline.get('c', [])
                    if len(link_c) >= 3:
                        url = link_c[2][0] if link_c[2] else ''
                        if url == r'\l' or '_Toc' in url:
                            return True
        elif t == 'BlockQuote':
            if _check_toc_in_blocks(c):
                return True
    return False


# Common mathematical Unicode characters
MATH_UNICODE_CHARS = set(
    '∑∏∫√∞≈≠≤≥±×÷∂∆∇αβγδεθλμσφω∈∉⊂⊃∩∪⊆⊇∀∃∴∵∼≡≅≈∝∠⊥′″°′∧∨¬⇒⇔→↔↑↓↗↘↙↖∘∙⋅⋆∗∎□■▲▼◆●○'
)

def is_formula_text(text: str) -> bool:
    """Detect if a text contains mathematical Unicode characters and no Chinese characters."""
    if not text or not text.strip():
        return False
    
    has_math = False
    for char in text:
        if char in MATH_UNICODE_CHARS:
            has_math = True
        # Check for Chinese characters (CJK Unified Ideographs range)
        if '\u4e00' <= char <= '\u9fff':
            return False
    
    return has_math



def extract_math_info(inlines: List[Dict]) -> List[Tuple[str, str]]:
    """从 inline 列表中提取所有公式信息。"""
    maths = []
    for inline in inlines:
        t = inline.get('t')
        c = inline.get('c')
        if t == 'Math':
            if len(c) >= 2:
                math_type = c[0][0] if c[0] else 'InlineMath'
                latex = c[1]
                maths.append((math_type, latex))
        elif t in ('Strong', 'Emph', 'Underline', 'Strikeout', 'Superscript', 'Subscript', 'Link'):
            maths.extend(extract_math_info(c[1] if t == 'Link' and len(c) >= 3 else c))
    return maths


# ────────────────────────────────────────────────────────────────────────────
# 4. 模板处理（复用 apply_template.py 中的函数）
# ────────────────────────────────────────────────────────────────────────────

def remove_body_placeholders(doc):
    """移除模板中的占位内容，保留节结构和标题。
    
    保留：
    - 封面节结构（包括表格）
    - 目录节标题
    - 图目录节标题
    - 表目录节标题
    - 所有 sectPr 段落（保持节结构）
    删除：
    - 正文节的所有内容（段落和表格）
    - 目录节和图目录节和表目录节的旧 TOC 内容
    """
    body = doc.element.body
    children = list(body)
    
    # 找到所有包含 sectPr 的段落索引
    section_break_indices = []
    for i, child in enumerate(children):
        tag = _get_tag_local_name(child.tag)
        if tag == 'p':
            pPr = child.find(qn('w:pPr'))
            if pPr is not None:
                sectPr = pPr.find(qn('w:sectPr'))
                if sectPr is not None:
                    section_break_indices.append(i)
    
    # 找到最后一个独立 sectPr 的索引
    last_sectPr_idx = None
    for i in range(len(children) - 1, -1, -1):
        if _get_tag_local_name(children[i].tag) == 'sectPr':
            last_sectPr_idx = i
            break
    
    # 如果少于4个 section break，使用原始逻辑
    if len(section_break_indices) < 4:
        if len(section_break_indices) >= 1:
            table_list_end = section_break_indices[-1]
            body_end = last_sectPr_idx if last_sectPr_idx is not None else len(children)
        else:
            table_list_end = last_sectPr_idx if last_sectPr_idx is not None else len(children)
            body_end = table_list_end
        
        to_remove = []
        for i in range(table_list_end, body_end):
            child = children[i]
            tag = _get_tag_local_name(child.tag)
            if tag in ('p', 'tbl'):
                if tag == 'p':
                    pPr = child.find(qn('w:pPr'))
                    if pPr is not None and pPr.find(qn('w:sectPr')) is not None:
                        # 保留 sectPr 段落，但删除 runs
                        for sub in list(child):
                            sub_tag = _get_tag_local_name(sub.tag)
                            if sub_tag != 'pPr':
                                child.remove(sub)
                        continue
                to_remove.append(child)
        
        for child in to_remove:
            body.remove(child)
        return
    
    # 标准模板结构（4+个 section break）
    # section_break_indices[0]: 封面节末尾
    # section_break_indices[1]: 目录节末尾
    # section_break_indices[2]: 图目录节末尾
    # section_break_indices[3]: 表目录节末尾
    
    # 清除目录节内容（保留标题和 sectPr）
    _clear_section_content(body, children, section_break_indices[0], section_break_indices[1], 
                          keep_titles=['目 录', '目录', '目  录'])
    
    # 清除图目录节内容（保留标题和 sectPr）
    _clear_section_content(body, children, section_break_indices[1], section_break_indices[2], 
                          keep_titles=['图目录'])
    
    # 清除表目录节内容（保留标题和 sectPr）
    _clear_section_content(body, children, section_break_indices[2], section_break_indices[3], 
                          keep_titles=['表目录'])
    
    # 删除正文节的所有内容（保留最后的 sectPr）
    if last_sectPr_idx is not None:
        to_remove = []
        for i in range(section_break_indices[3] + 1, last_sectPr_idx):
            child = children[i]
            tag = _get_tag_local_name(child.tag)
            if tag in ('p', 'tbl'):
                to_remove.append(child)
        
        for child in to_remove:
            body.remove(child)


def _clear_section_content(body, children, start_idx, end_idx, keep_titles=None):
    """清除节中的内容，但保留标题和 sectPr 段落。"""
    keep_titles = keep_titles or []
    to_remove = []
    
    for i in range(start_idx + 1, end_idx):
        child = children[i]
        tag = _get_tag_local_name(child.tag)
        if tag == 'p':
            # 检查是否是 sectPr 段落
            pPr = child.find(qn('w:pPr'))
            if pPr is not None and pPr.find(qn('w:sectPr')) is not None:
                # 保留 sectPr 段落，但删除 runs
                for sub in list(child):
                    sub_tag = _get_tag_local_name(sub.tag)
                    if sub_tag != 'pPr':
                        child.remove(sub)
                continue
            
            # 检查是否是标题段落
            text = ''
            for r in child.findall('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}r'):
                for t in r.findall('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t'):
                    if t.text:
                        text += t.text
            
            # 如果文本是标题，保留
            if any(title in text for title in keep_titles):
                continue
            
            # 删除其他内容
            to_remove.append(child)
        elif tag == 'tbl':
            to_remove.append(child)
    
    for child in to_remove:
        body.remove(child)



# ────────────────────────────────────────────────────────────────────────────
# 5. 内容填充
# ────────────────────────────────────────────────────────────────────────────

def add_heading(doc, level: int, text: str):
    """添加标题段落，应用模板 Heading 样式，无缩进。"""
    style_name = f'Heading {min(level, 9)}'
    p = doc.add_paragraph(style=style_name)
    _set_no_indent(p)
    p.add_run(text)
    return p


def add_paragraph_from_inlines(doc, inlines: List[Dict], style='Normal', source_doc=None, target_doc_ref=None):
    """从 pandoc inline 列表添加段落，保留格式，无缩进。如果内容为空则跳过。"""
    text = inlines_to_text(inlines) if isinstance(inlines, list) else ''
    if not text.strip():
        return None
    p = doc.add_paragraph(style=style)
    _set_no_indent(p)
    inlines_to_runs(p, inlines, source_doc, target_doc_ref)
    return p




def parse_length(val: str):
    """Parse a length string like '4.69in', '15cm' and return a docx.shared.Length object."""
    from docx.shared import Inches, Cm, Pt, Emu
    val = val.strip()
    if val.endswith('in'):
        return Inches(float(val[:-2]))
    elif val.endswith('cm'):
        return Cm(float(val[:-2]))
    elif val.endswith('mm'):
        return Cm(float(val[:-2]) / 10)
    elif val.endswith('pt'):
        return Pt(float(val[:-2]))
    elif val.endswith('px'):
        return Inches(float(val[:-2]) / 96)
    return None


def latex_to_omml_xml(latex: str, math_type: str = 'InlineMath') -> str:
    """Convert LaTeX to OMML XML string using pandoc."""
    import tempfile
    import zipfile
    import os
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False) as f:
        if math_type == 'DisplayMath':
            f.write(f'$$\n{latex}\n$$\n')
        else:
            f.write(f'${latex}$')
        md_path = f.name
    
    try:
        with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as f:
            docx_path = f.name
        
        result = subprocess.run(
            ['pandoc', md_path, '-f', 'markdown', '-t', 'docx', '-o', docx_path],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            return None
        
        with zipfile.ZipFile(docx_path, 'r') as z:
            doc_xml = z.read('word/document.xml').decode('utf-8')
            import re as regex
            match = regex.search(r'<m:oMath[^>]*>.*?</m:oMath>', doc_xml, regex.DOTALL)
            if match:
                xml = match.group(0)
                # Add namespace declaration if not present
                if 'xmlns:m=' not in xml:
                    xml = xml.replace('<m:oMath', '<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"')
                return xml
            match = regex.search(r'<m:oMathPara[^>]*>.*?</m:oMathPara>', doc_xml, regex.DOTALL)
            if match:
                xml = match.group(0)
                if 'xmlns:m=' not in xml:
                    xml = xml.replace('<m:oMathPara', '<m:oMathPara xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"')
                return xml
        return None
    finally:
        os.unlink(md_path)
        if os.path.exists(docx_path):
            os.unlink(docx_path)

def add_table_from_json(doc, table_data: List[Any], media_dir: str):
    """从 pandoc JSON Table 结构添加表格，支持合并单元格（rowspan/colspan）。"""
    if len(table_data) < 6:
        return None
    
    # table_data = [Attr, Caption, [ColSpec], TableHead, [TableBody], TableFoot]
    caption_data = table_data[1]  # [short_caption, long_caption]
    colspecs = table_data[2]      # [[Align, ColWidth], ...]
    thead = table_data[3]       # [Attr, [Row]]
    tbodies = table_data[4]     # [[TableBody]]
    tfoot = table_data[5]       # [Attr, [Row]]
    
    def extract_rows(rows_data):
        """提取行数据，包含 rowspan/colspan 信息。"""
        result = []
        for row in rows_data:
            if isinstance(row, list) and len(row) >= 2:
                cells = row[1]  # list of Cell
                cell_info = []
                for cell in cells:
                    if isinstance(cell, list) and len(cell) >= 5:
                        cell_info.append({
                            'text': '\n'.join(blocks_to_text(cell[4])),
                            'rowspan': cell[2] if len(cell) > 2 else 1,
                            'colspan': cell[3] if len(cell) > 3 else 1,
                        })
                result.append(cell_info)
        return result
    
    # 提取表头行
    header_rows = extract_rows(thead[1]) if isinstance(thead, list) and len(thead) >= 2 else []
    
    # 提取数据行
    body_rows = []
    if isinstance(tbodies, list):
        for tbody in tbodies:
            if isinstance(tbody, list) and len(tbody) >= 4:
                body_rows.extend(extract_rows(tbody[3]))
    
    # 提取 foot 行
    foot_rows = extract_rows(tfoot[1]) if isinstance(tfoot, list) and len(tfoot) >= 2 else []
    
    all_rows = header_rows + body_rows + foot_rows
    if not all_rows:
        return None
    
    # 使用 colspecs 确定物理列数（更准确）
    physical_cols = max(sum(c['colspan'] for c in row) for row in all_rows) if all_rows else 0
    num_cols = max(len(colspecs), physical_cols) if colspecs else physical_cols
    
    table = doc.add_table(rows=len(all_rows), cols=num_cols)
    try:
        table.style = 'Table Grid'
    except Exception:
        pass
    
    # 用 occupied 网格追踪哪些位置已被上方/左方的合并单元格占用
    occupied = [[False] * num_cols for _ in range(len(all_rows))]
    merge_info = []  # [(row, col, rowspan, colspan), ...]
    cell_refs = {}   # (row, col) -> _Cell 引用，merge 时直接使用避免索引错乱
    
    for row_idx, row in enumerate(all_rows):
        col_idx = 0
        for cell_info in row:
            # 跳过已被占用的位置
            while col_idx < num_cols and occupied[row_idx][col_idx]:
                col_idx += 1
            if col_idx >= num_cols:
                break
            
            # 填充单元格内容
            cell = table.rows[row_idx].cells[col_idx]
            cell.text = cell_info['text']
            for p in cell.paragraphs:
                _set_no_indent(p)
            
            # 保存引用供后续 merge 使用
            cell_refs[(row_idx, col_idx)] = cell
            
            rspan = cell_info['rowspan']
            cspan = cell_info['colspan']
            
            # 标记本单元格覆盖的区域为已占用
            for r in range(rspan):
                for c in range(cspan):
                    if row_idx + r < len(all_rows) and col_idx + c < num_cols:
                        occupied[row_idx + r][col_idx + c] = True
            
            # 记录需要合并的单元格
            if rspan > 1 or cspan > 1:
                merge_info.append((row_idx, col_idx, rspan, cspan))
            
            col_idx += cspan
    
    # 执行合并：按位置排序（先左上后右下），避免先合并大区域导致 table.cell() 索引错乱
    # top_left 使用 cell_refs（已保存的引用），bottom_right 使用 table.cell()（此时还未被合并）
    merge_info.sort(key=lambda x: (x[0], x[1]))
    for row_idx, col_idx, rspan, cspan in merge_info:
        top_left = cell_refs[(row_idx, col_idx)]
        bottom_right = table.cell(row_idx + rspan - 1, col_idx + cspan - 1)
        top_left.merge(bottom_right)
    
    # 设置表格 autofit（根据内容调整）
    try:
        tbl = table._tbl
        tblPr = tbl.find(qn('w:tblPr'))
        if tblPr is None:
            tblPr = parse_xml(f'<w:tblPr {nsdecls("w")}></w:tblPr>')
            tbl.insert(0, tblPr)
        
        tblW = tblPr.find(qn('w:tblW'))
        if tblW is None:
            tblW = parse_xml(f'<w:tblW {nsdecls("w")} w:type="auto" w:w="0"/>')
            tblPr.append(tblW)
        else:
            tblW.set(qn('w:type'), 'auto')
            tblW.set(qn('w:w'), '0')
        
        tblLayout = tblPr.find(qn('w:tblLayout'))
        if tblLayout is None:
            tblLayout = parse_xml(f'<w:tblLayout {nsdecls("w")} w:type="autofit"/>')
            tblPr.append(tblLayout)
        else:
            tblLayout.set(qn('w:type'), 'autofit')
        
        tblGrid = tbl.find(qn('w:tblGrid'))
        if tblGrid is not None:
            for gridCol in tblGrid.findall(qn('w:gridCol')):
                gridCol.attrib.pop(qn('w:w'), None)
        
        for row in table.rows:
            for cell in row.cells:
                tcPr = cell._tc.find(qn('w:tcPr'))
                if tcPr is not None:
                    tcW = tcPr.find(qn('w:tcW'))
                    if tcW is not None:
                        tcPr.remove(tcW)
    except Exception:
        pass
    
    # 加粗表头
    if header_rows:
        for j in range(num_cols):
            try:
                cell = table.rows[0].cells[j]
                for p in cell.paragraphs:
                    for run in p.runs:
                        run.bold = True
            except Exception:
                pass
    
    # 表格题注
    caption_text = ''
    if isinstance(caption_data, list) and len(caption_data) >= 2:
        if caption_data[1]:
            caption_text = inlines_to_text(caption_data[1])
        elif caption_data[0]:
            caption_text = inlines_to_text(caption_data[0])
    
    if caption_text:
        p = doc.add_paragraph(style='Caption')
        _set_no_indent(p)
        p.add_run(caption_text)
    
    return table


def blocks_to_text(blocks: List[Dict]) -> List[str]:
    """将 block 列表转换为文本列表。"""
    texts = []
    for block in blocks:
        t = block.get('t')
        c = block.get('c')
        if t == 'Para' or t == 'Plain':
            texts.append(inlines_to_text(c))
        elif t == 'Header':
            texts.append(inlines_to_text(c[2]) if len(c) > 2 else '')
    return texts


def add_image(doc, image_path: str, alt_text: str = '', chapter_num: int = 1, figure_num: int = 0, width=None, height=None):
    """添加图片到文档，保留原始尺寸，居中、无缩进，添加题注（SEQ 域）。
    
    过滤掉过小的图片（可能是特殊符号/占位符）。
    
    Args:
        width: 图片宽度（docx.shared.Length 对象），None 表示使用图片原始尺寸。
        height: 图片高度（docx.shared.Length 对象），None 表示按宽度比例缩放。
    """
    try:
        if not os.path.exists(image_path):
            return False
        
        # 过滤掉过小的图片（特殊符号/占位符）
        from PIL import Image as PILImage
        with PILImage.open(image_path) as img:
            img_width, img_height = img.size
            # 过滤：小于 20x20 像素，或面积小于 400 像素
            if img_width < 20 or img_height < 20 or (img_width * img_height) < 400:
                print(f"⚠️  过滤过小图片 ({img_width}x{img_height}): {os.path.basename(image_path)}")
                return False
        
        # 图片段落：居中、无缩进
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _set_no_indent(p)
        run = p.add_run()
        
        # 添加图片，保留原始尺寸（或按 pandoc 提取的尺寸）
        if width is not None:
            if height is not None:
                pic = run.add_picture(image_path, width=width, height=height)
            else:
                pic = run.add_picture(image_path, width=width)
        else:
            pic = run.add_picture(image_path)
        
        # 题注段落：Caption 样式，居中，无缩进，带 SEQ 域
        if figure_num > 0:
            try:
                caption = doc.add_paragraph(style='Caption')
            except KeyError:
                caption = doc.add_paragraph()
            caption.alignment = WD_ALIGN_PARAGRAPH.CENTER
            _set_no_indent(caption)
            
            # 添加 "图" 标签
            caption.add_run("图 ")
            
            # 添加 SEQ 域: { SEQ 图 \* ARABIC }
            _add_seq_field(caption, "图", f"{chapter_num}-{figure_num}")
            
            # 如果 alt_text 存在，添加空格和标题
            if alt_text:
                caption.add_run(f" {alt_text}")
        return True
    except Exception as e:
        print(f"⚠️  图片插入失败 {image_path}: {e}")
        return False



def _set_no_indent(paragraph):
    """显式清除段落的首行缩进和左缩进，覆盖样式默认值。"""
    from docx.oxml import parse_xml
    from docx.oxml.ns import qn, nsdecls
    
    pPr = paragraph._p.get_or_add_pPr()
    ind = pPr.find(qn('w:ind'))
    if ind is None:
        ind = parse_xml(f'<w:ind {nsdecls("w")} w:firstLine="0" w:firstLineChars="0" w:left="0"/>')
        pPr.append(ind)
    else:
        ind.set(qn('w:firstLine'), '0')
        ind.set(qn('w:firstLineChars'), '0')
        ind.set(qn('w:left'), '0')
    
    paragraph.paragraph_format.first_line_indent = Cm(0)
    paragraph.paragraph_format.left_indent = Cm(0)


def _add_seq_field(paragraph, seq_name: str, display_text: str):
    """在段落中添加 SEQ 域，display_text 为显示文本。"""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    
    # 开始域
    run1 = paragraph.add_run()
    fldChar1 = OxmlElement('w:fldChar')
    fldChar1.set(qn('w:fldCharType'), 'begin')
    run1._r.append(fldChar1)
    
    # 指令文本
    run2 = paragraph.add_run()
    instrText = OxmlElement('w:instrText')
    instrText.set(qn('xml:space'), 'preserve')
    instrText.text = f' SEQ {seq_name} \\* ARABIC '
    run2._r.append(instrText)
    
    # 分隔符
    run3 = paragraph.add_run()
    fldChar2 = OxmlElement('w:fldChar')
    fldChar2.set(qn('w:fldCharType'), 'separate')
    run3._r.append(fldChar2)
    
    # 显示数字（自定义显示文本）
    run4 = paragraph.add_run()
    run4.text = display_text
    
    # 结束域
    run5 = paragraph.add_run()
    fldChar3 = OxmlElement('w:fldChar')
    fldChar3.set(qn('w:fldCharType'), 'end')
    run5._r.append(fldChar3)


def _add_toc_fields(doc):
    """在目录节、图目录节、表目录节添加 TOC 域。"""
    # 先收集所有匹配位置，然后按索引从大到小插入（避免索引偏移）
    toc_items = []
    for i, p in enumerate(doc.paragraphs):
        text = p.text.strip() if p.text else ''
        # 清理空格后匹配（处理 "目 录" / "目  录" / "目录" 等变体）
        clean = text.replace(' ', '').replace('\u3000', '')
        if clean == '目录':
            toc_items.append((i, 'TOC \\o "1-3" \\h \\z \\u '))
        elif clean == '图目录':
            toc_items.append((i, 'TOC \\h \\z \\c "图" '))
        elif clean == '表目录':
            toc_items.append((i, 'TOC \\h \\z \\c "表" '))
    
    # 按索引从大到小插入，避免前面的插入影响后面的索引
    for i, toc_instr in reversed(toc_items):
        _insert_toc_after_para(doc, i, toc_instr)


def _insert_toc_after_para(doc, para_idx, toc_instr):
    """在指定段落后插入 TOC 域段落。"""
    p = doc.paragraphs[para_idx]
    
    # 创建新段落，插入 TOC 域
    new_p = OxmlElement('w:p')
    
    # 段落样式（使用 toc 1 或 table of figures）
    pPr = parse_xml(f'<w:pPr {nsdecls("w")}><w:pStyle w:val="toc 1"/></w:pPr>')
    new_p.append(pPr)
    
    # 添加 TOC 域
    # { TOC ... }
    # fldChar begin
    run1 = OxmlElement('w:r')
    fldChar1 = OxmlElement('w:fldChar')
    fldChar1.set(qn('w:fldCharType'), 'begin')
    run1.append(fldChar1)
    new_p.append(run1)
    
    # instrText
    run2 = OxmlElement('w:r')
    instrText = OxmlElement('w:instrText')
    instrText.set(qn('xml:space'), 'preserve')
    instrText.text = toc_instr
    run2.append(instrText)
    new_p.append(run2)
    
    # fldChar separate
    run3 = OxmlElement('w:r')
    fldChar2 = OxmlElement('w:fldChar')
    fldChar2.set(qn('w:fldCharType'), 'separate')
    run3.append(fldChar2)
    new_p.append(run3)
    
    # 占位文本（会被 Word 更新时替换）
    run4 = OxmlElement('w:r')
    t = OxmlElement('w:t')
    t.text = '（按 F9 更新目录）'
    run4.append(t)
    new_p.append(run4)
    
    # fldChar end
    run5 = OxmlElement('w:r')
    fldChar3 = OxmlElement('w:fldChar')
    fldChar3.set(qn('w:fldCharType'), 'end')
    run5.append(fldChar3)
    new_p.append(run5)
    
    # 插入到段落之后
    p._p.addnext(new_p)


def _replace_cover_page(doc, data):
    """从源文档数据中提取封面内容，替换模板封面占位符。
    
    模板封面结构：
    - 响应文件（标题）
    - 项目名称：XXX
    - 项目编号：XXX
    - 采 购 人
    - 供 应 商
    - 供应商：（印章） 法定代表人：（法人章）
    - 年 月 日
    
    从源文档提取前几个非空段落作为封面内容，替换模板中的占位文本。
    """
    blocks = data.get('blocks', [])
    
    # 提取封面内容（非空段落，跳过目录和 TOC）
    cover_texts = []
    for block in blocks:
        t = block.get('t')
        c = block.get('c')
        if t == 'Para' or t == 'Plain':
            text = inlines_to_text(c) if isinstance(c, list) else ''
            text = text.strip()
            # 跳过空段落和目录内容
            if text and not text.startswith('目录') and not text.startswith('目 录'):
                # 跳过包含 TOC 链接的内容
                has_toc_link = False
                for inline in (c if isinstance(c, list) else []):
                    if inline.get('t') == 'Link':
                        link_c = inline.get('c', [])
                        if len(link_c) >= 3:
                            url = link_c[2][0] if link_c[2] else ''
                            if url == r'\l' or '_Toc' in url:
                                has_toc_link = True
                                break
                if not has_toc_link:
                    cover_texts.append(text)
    
    if not cover_texts:
        return
    
    # 找到模板封面中的占位符段落并替换（保留模板格式）
    for i, p in enumerate(doc.paragraphs[:30]):
        text = p.text.strip() if p.text else ''
        
        # 替换项目名称段落（模板中任何"项目名称："开头的段落）
        if text.startswith('项目名称：'):
            # 从源文档封面中提取项目名称
            project_name = None
            for ct in cover_texts:
                if '项目名称' in ct:
                    project_name = ct
                    break
            if not project_name and len(cover_texts) > 2:
                project_name = cover_texts[2]  # 通常第3个是项目名称
            
            if project_name:
                # 保留模板格式，只替换文本
                if p.runs:
                    # 如果只有一个 run，直接替换文本
                    if len(p.runs) == 1:
                        p.runs[0].text = project_name
                    else:
                        # 多个 runs：在第一个 run 中设置完整文本，删除其他 runs
                        first_run = p.runs[0]
                        first_run.text = project_name
                        for r in p.runs[1:]:
                            r._element.getparent().remove(r._element)
        
        # 替换项目编号（保留模板格式）
        elif text.startswith('项目编号：') and 'XXX' in text:
            # 保持原样或从源文档提取编号
            # 目前没有找到源文档中的项目编号，所以保留 XXX
            # 如果后续需要从源文档提取，可以在这里添加逻辑
            pass
        
        # 替换其他封面内容（如果源文档有对应内容）
        # 这里可以添加更多替换规则


# ────────────────────────────────────────────────────────────────────────────
# 6. 主转换流程
# ────────────────────────────────────────────────────────────────────────────

def process_blocks(blocks: List[Dict], output_doc, media_dir: str, stats: Dict, source_doc=None, target_doc_ref=None):
    """处理 pandoc block 列表，填充到输出文档。"""
    for block in blocks:
        # 跳过目录/TOC 内容
        if is_toc_block(block):
            continue
        
        t = block.get('t')
        c = block.get('c')
        
        if t == 'Header':
            level = c[0] if len(c) > 0 else 1
            # 遇到一级标题，新章节开始
            if level == 1:
                # 如果已有图片，说明前一章结束，章节号+1
                if stats.get('figure', 0) > 0 or stats.get('headings', 0) > 0:
                    stats['chapter'] = stats.get('chapter', 1) + 1
                stats['figure'] = 0
            inlines = c[2] if len(c) > 2 else []
            text = inlines_to_text(inlines)
            # 清理标题中的原始编号（模板有自动编号）
            text = clean_heading_number(text)
            add_heading(output_doc, level, text)
            stats['headings'] += 1
        
        elif t == 'Para':
            inlines = c if isinstance(c, list) else []
            # 检查是否包含图片
            images = extract_image_info(inlines)
            if images:
                # 添加图片（保留原始尺寸）
                for alt, url, img_width, img_height in images:
                    if not os.path.isabs(url):
                        full_path = os.path.join(media_dir, url)
                    else:
                        full_path = url
                    stats['figure'] += 1
                    add_image(output_doc, full_path, alt, stats.get('chapter', 1), stats.get('figure', 0), width=img_width, height=img_height)
                    stats['images'] += 1
                # 过滤掉图片 inline，剩余内容作为普通段落处理
                non_img_inlines = [i for i in inlines if i.get('t') != 'Image']
                if non_img_inlines:
                    # 检查是否有公式（Math 节点）
                    maths = extract_math_info(non_img_inlines)
                    if maths:
                        p = output_doc.add_paragraph(style='公式')
                        _set_no_indent(p)
                        inlines_to_runs(p, non_img_inlines, source_doc, target_doc_ref)
                        stats['formulas'] += 1
                    else:
                        # 检查是否有纯文本数学公式
                        text = inlines_to_text(non_img_inlines)
                        if is_formula_text(text):
                            p = output_doc.add_paragraph(style='公式')
                            _set_no_indent(p)
                            omml_xml = latex_to_omml_xml(text, 'InlineMath')
                            if omml_xml:
                                try:
                                    from lxml import etree
                                    omml_element = etree.fromstring(omml_xml)
                                    p._p.append(omml_element)
                                except Exception:
                                    p.add_run(text)
                            else:
                                p.add_run(text)
                            stats['formulas'] += 1
                        else:
                            add_paragraph_from_inlines(output_doc, non_img_inlines, 'Normal', source_doc, target_doc_ref)
                            stats['paragraphs'] += 1
                continue
            
            # 检查是否有公式（Math 节点）
            maths = extract_math_info(inlines)
            if maths:
                # 有公式，用公式样式
                p = output_doc.add_paragraph(style='公式')
                _set_no_indent(p)
                inlines_to_runs(p, inlines, source_doc, target_doc_ref)
                stats['formulas'] += 1
            else:
                # 检查是否有纯文本数学公式（Unicode 数学字符）
                text = inlines_to_text(inlines)
                if is_formula_text(text):
                    # 纯文本公式，转换为 OMML
                    p = output_doc.add_paragraph(style='公式')
                    _set_no_indent(p)
                    omml_xml = latex_to_omml_xml(text, 'InlineMath')
                    if omml_xml:
                        try:
                            from lxml import etree
                            omml_element = etree.fromstring(omml_xml)
                            p._p.append(omml_element)
                        except Exception:
                            # 回退：纯文本
                            p.add_run(text)
                    else:
                        p.add_run(text)
                    stats['formulas'] += 1
                else:
                    add_paragraph_from_inlines(output_doc, inlines, 'Normal', source_doc, target_doc_ref)
                    stats['paragraphs'] += 1
        
        elif t == 'Plain':
            inlines = c if isinstance(c, list) else []
            text = inlines_to_text(inlines)
            if text.strip():
                add_paragraph_from_inlines(output_doc, inlines, 'Normal', source_doc, target_doc_ref)
                stats['paragraphs'] += 1
        
        elif t == 'Table':
            table_data = c if isinstance(c, list) else []
            # 获取表格标题文本
            caption_text = ''
            if isinstance(table_data, list) and len(table_data) >= 2:
                caption_data = table_data[1]
                if isinstance(caption_data, list) and len(caption_data) >= 2:
                    if caption_data[1]:
                        caption_text = inlines_to_text(caption_data[1])
                    elif caption_data[0]:
                        caption_text = inlines_to_text(caption_data[0])
            
            # 添加表格
            add_table_from_json(output_doc, table_data, media_dir)
            stats['tables'] += 1
            stats['table'] += 1
            
            # 添加表格题注（Caption），带 SEQ 域
            chapter_num = stats.get('chapter', 1)
            table_num = stats.get('table', 0)
            if table_num > 0:
                try:
                    caption = output_doc.add_paragraph(style='Caption')
                except KeyError:
                    caption = output_doc.add_paragraph()
                caption.alignment = WD_ALIGN_PARAGRAPH.CENTER
                _set_no_indent(caption)
                caption.add_run("表 ")
                _add_seq_field(caption, "表", f"{chapter_num}-{table_num}")
                if caption_text:
                    caption.add_run(f" {caption_text}")
            
        elif t == 'BulletList':
            items = c if isinstance(c, list) else []
            for item in items:
                for item_block in item:
                    item_t = item_block.get('t')
                    item_c = item_block.get('c')
                    if item_t == 'Para' or item_t == 'Plain':
                        # 跳过空段落
                        text = inlines_to_text(item_c) if isinstance(item_c, list) else ''
                        if not text.strip():
                            continue
                        try:
                            p = output_doc.add_paragraph(style='List Bullet')
                        except KeyError:
                            p = output_doc.add_paragraph(style='Normal')
                        _set_no_indent(p)
                        inlines_to_runs(p, item_c, source_doc, target_doc_ref)
                        stats['lists'] += 1
                    else:
                        process_blocks([item_block], output_doc, media_dir, stats, source_doc, target_doc_ref)
        
        elif t == 'OrderedList':
            list_attr = c[0] if len(c) > 0 else {}
            items = c[1] if len(c) > 1 else []
            for idx, item in enumerate(items, start=1):
                for item_block in item:
                    item_t = item_block.get('t')
                    item_c = item_block.get('c')
                    if item_t == 'Para' or item_t == 'Plain':
                        # 跳过空段落
                        text = inlines_to_text(item_c) if isinstance(item_c, list) else ''
                        if not text.strip():
                            continue
                        try:
                            p = output_doc.add_paragraph(style='List Number')
                        except KeyError:
                            p = output_doc.add_paragraph(style='Normal')
                        _set_no_indent(p)
                        p.add_run(f"{idx}. ")
                        inlines_to_runs(p, item_c, source_doc, target_doc_ref)
                        stats['lists'] += 1
                    else:
                        process_blocks([item_block], output_doc, media_dir, stats, source_doc, target_doc_ref)
        
        elif t == 'BlockQuote':
            quote_blocks = c if isinstance(c, list) else []
            process_blocks(quote_blocks, output_doc, media_dir, stats, source_doc, target_doc_ref)
        
        elif t == 'Div':
            div_attr = c[0] if len(c) > 0 else {}
            div_blocks = c[1] if len(c) > 1 else []
            process_blocks(div_blocks, output_doc, media_dir, stats, source_doc, target_doc_ref)
        
        elif t == 'BulletList':
            items = c if isinstance(c, list) else []
            for item in items:
                for item_block in item:
                    item_t = item_block.get('t')
                    item_c = item_block.get('c')
                    if item_t == 'Para' or item_t == 'Plain':
                        # 跳过空段落
                        text = inlines_to_text(item_c) if isinstance(item_c, list) else ''
                        if not text.strip():
                            continue
                        try:
                            p = output_doc.add_paragraph(style='List Bullet')
                        except KeyError:
                            p = output_doc.add_paragraph(style='Normal')
                        _set_no_indent(p)
                        inlines_to_runs(p, item_c, source_doc, target_doc_ref)
                        stats['lists'] += 1
                    else:
                        process_blocks([item_block], output_doc, media_dir, stats, source_doc, target_doc_ref)
        
        elif t == 'OrderedList':
            list_attr = c[0] if len(c) > 0 else {}
            items = c[1] if len(c) > 1 else []
            for idx, item in enumerate(items, start=1):
                for item_block in item:
                    item_t = item_block.get('t')
                    item_c = item_block.get('c')
                    if item_t == 'Para' or item_t == 'Plain':
                        # 跳过空段落
                        text = inlines_to_text(item_c) if isinstance(item_c, list) else ''
                        if not text.strip():
                            continue
                        try:
                            p = output_doc.add_paragraph(style='List Number')
                        except KeyError:
                            p = output_doc.add_paragraph(style='Normal')
                        _set_no_indent(p)
                        p.add_run(f"{idx}. ")
                        inlines_to_runs(p, item_c, source_doc, target_doc_ref)
                        stats['lists'] += 1
                    else:
                        process_blocks([item_block], output_doc, media_dir, stats, source_doc, target_doc_ref)
        
        elif t == 'BlockQuote':
            quote_blocks = c if isinstance(c, list) else []
            process_blocks(quote_blocks, output_doc, media_dir, stats, source_doc, target_doc_ref)
        
        elif t == 'Div':
            div_attr = c[0] if len(c) > 0 else {}
            div_blocks = c[1] if len(c) > 1 else []
            process_blocks(div_blocks, output_doc, media_dir, stats, source_doc, target_doc_ref)
        
        elif t == 'LineBlock':
            # 诗歌/歌词格式，按行处理
            for line in c:
                if isinstance(line, list):
                    text = inlines_to_text(line)
                    if text.strip():
                        add_paragraph_from_inlines(output_doc, line, 'Normal', source_doc, target_doc_ref)
                        stats['paragraphs'] += 1


def md_bridge(source_path: str, template_path: str, output_path: str):
    """通过 pandoc JSON 中转，将源文档转换为模板格式。"""
    
    # 检查 pandoc 是否可用
    rc, _, _ = _run_cmd(["pandoc", "--version"])
    if rc != 0:
        print("❌ 错误：pandoc 未安装。请运行 apt install pandoc 或 brew install pandoc。", file=sys.stderr)
        sys.exit(1)
    
    # 创建临时工作目录
    work_dir = tempfile.mkdtemp(prefix='md_bridge_')
    try:
        # 1. docx → JSON
        json_path, media_dir, data = docx_to_json(source_path, work_dir)
        
        # 2. 基于模板创建输出文档
        output_doc = Document(template_path)
        remove_body_placeholders(output_doc)
        
        # 3. 处理 JSON blocks
        # 先提取封面内容（前几个非空段落），跳过封面和目录内容
        blocks = data.get('blocks', [])
        
        # 找到封面内容的结束位置（第一个非空 Heading 2+ 或目录标题之前）
        # 注意：Heading 1 可能是封面标题，不视为正文开始
        cover_end = 0
        found_first_heading = False
        for i, block in enumerate(blocks):
            t = block.get('t')
            if t == 'Header':
                c = block.get('c', [])
                if len(c) >= 3:
                    inlines = c[2]
                    text = inlines_to_text(inlines) if isinstance(inlines, list) else ''
                    text = text.strip()
                    if text:
                        level = c[0] if len(c) > 0 else 1
                        if not found_first_heading:
                            # 第一个非空 Heading 通常是封面标题（如 Heading 1）
                            found_first_heading = True
                            # 继续扫描，不终止
                            continue
                        else:
                            # 第二个非空 Heading 是正文开始
                            cover_end = i
                            break
                # 空标题，继续
                continue
            if t == 'Para' or t == 'Plain':
                c = block.get('c', [])
                text = inlines_to_text(c) if isinstance(c, list) else ''
                text = text.strip()
                # 跳过"目录"标题和 TOC 内容
                if text == '目录' or text.startswith('目 录') or text.startswith('目  录'):
                    cover_end = i
                    break
        
        # 如果一直没找到封面结束，默认到第一个非空 block 之后
        if cover_end == 0 and found_first_heading:
            # 第一个非空 Heading 之后的内容也视为封面，直到遇到目录或空标题
            for i in range(1, len(blocks)):
                b = blocks[i]
                t = b.get('t')
                if t in ('Para', 'Plain'):
                    c = b.get('c', [])
                    text = inlines_to_text(c) if isinstance(c, list) else ''
                    text = text.strip()
                    if text == '目录' or text.startswith('目 录') or text.startswith('目  录'):
                        cover_end = i
                        break
                    # 遇到非空段落，更新 cover_end
                    if text:
                        cover_end = i + 1
            # 如果没找到目录，默认前10个 block
            if cover_end == 0:
                cover_end = min(10, len(blocks))
        
        # 提取封面内容用于替换模板封面（只包含到 cover_end 之前的段落）
        cover_blocks = blocks[:cover_end]
        # body_blocks 从 cover_end 开始，但跳过"目录"标题和 TOC 内容
        body_blocks = []
        for i in range(cover_end, len(blocks)):
            block = blocks[i]
            t = block.get('t')
            c = block.get('c', [])
            # 跳过目录/TOC 内容
            if is_toc_block(block):
                continue
            if t == 'Para' or t == 'Plain':
                text = inlines_to_text(c) if isinstance(c, list) else ''
                text = text.strip()
                if text == '目录' or text.startswith('目 录') or text.startswith('目  录'):
                    continue
            body_blocks.append(block)
        
        # 替换模板封面
        _replace_cover_page(output_doc, {'blocks': cover_blocks})
        
        stats = {
            'headings': 0,
            'paragraphs': 0,
            'tables': 0,
            'images': 0,
            'formulas': 0,
            'lists': 0,
            'chapter': 1,  # 当前章节编号（Heading 1 级别）
            'figure': 0,   # 当前章节内图片计数
            'table': 0,    # 当前章节内表格计数
        }
        
        # 处理正文内容（跳过封面和目录）
        # 图片尺寸从 pandoc JSON 中提取，不再强制缩放
        process_blocks(body_blocks, output_doc, media_dir, stats)
        
        # 4. 应用模板页面设置
        template_doc = Document(template_path)
        template_body_section = template_doc.sections[-1]
        for section in output_doc.sections:
            section.page_width = template_body_section.page_width
            section.page_height = template_body_section.page_height
            section.top_margin = template_body_section.top_margin
            section.bottom_margin = template_body_section.bottom_margin
            section.left_margin = template_body_section.left_margin
            section.right_margin = template_body_section.right_margin
            section.header_distance = template_body_section.header_distance
            section.footer_distance = template_body_section.footer_distance
            section.gutter = template_body_section.gutter
        
        # 5. 删除所有空段落（没有文本内容也没有图片的段落）
        # 注意：这会删除模板中的空段落占位符，但保留有内容的段落
        # 特别注意：
        #  1. 不要删除包含 sectPr 的段落，否则会丢失节结构
        #  2. 不要删除封面节的空段落（封面排版需要空行）
        body = output_doc.element.body
        children = list(body)
        
        # 找到第一个 section break（封面节结束位置）
        cover_end_idx = 0
        for i, child in enumerate(children):
            tag = _get_tag_local_name(child.tag)
            if tag == 'p':
                pPr = child.find(qn('w:pPr'))
                if pPr is not None and pPr.find(qn('w:sectPr')) is not None:
                    cover_end_idx = i
                    break
        
        children_to_remove = []
        for i, child in enumerate(children):
            # 跳过封面节（从 body 开头到第一个 section break）
            if i <= cover_end_idx:
                continue
            tag = _get_tag_local_name(child.tag)
            if tag == 'p':
                has_text = False
                has_drawing = False
                has_sectPr = False
                pPr = child.find(qn('w:pPr'))
                if pPr is not None and pPr.find(qn('w:sectPr')) is not None:
                    has_sectPr = True
                for r in child.findall('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}r'):
                    for t in r.findall('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t'):
                        if t.text and t.text.strip():
                            has_text = True
                    if r.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}drawing') is not None:
                        has_drawing = True
                # 只删除没有文本、没有图片、没有 sectPr 的段落
                if not has_text and not has_drawing and not has_sectPr:
                    children_to_remove.append(child)
        
        for child in children_to_remove:
            body.remove(child)
        
        # 6. 在目录节和图目录节和表目录节生成新的 TOC 域
        # 找到各节的标题段落，在其后添加 TOC 域
        _add_toc_fields(output_doc)
        
        # 7. 封面内容已在 process_blocks 之前替换，无需再次替换
        # _replace_cover_page(output_doc, data)
        
        # 8. 保存
        output_doc.save(output_path)
        
        # 6. 输出统计
        print(f"✅ MD 中转转换完成：{output_path}")
        print(f"   标题：{stats['headings']} 个")
        print(f"   正文段落：{stats['paragraphs']} 个")
        print(f"   表格：{stats['tables']} 个")
        print(f"   图片：{stats['images']} 个")
        print(f"   公式：{stats['formulas']} 个")
        print(f"   列表：{stats['lists']} 个")
        print()
        print("⚠️  注意：")
        print("   1. 公式已自动转换为 OMML 格式（若源文档含 LaTeX 公式）")
        print("   2. 目录（TOC）字段在 Word 中打开后需按 F9 更新")
        print("   3. 图片路径已解析，保留原始尺寸")
        
    finally:
        # 清理临时目录
        shutil.rmtree(work_dir, ignore_errors=True)


# ────────────────────────────────────────────────────────────────────────────
# 7. 命令行入口
# ────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description='通过 pandoc JSON 中转将 Word 文档转换为模板格式。'
    )
    parser.add_argument('--source', '-s', required=True, help='源文档路径（.docx）')
    parser.add_argument('--template', '-t', required=True, help='模板文档路径（.docx）')
    parser.add_argument('--output', '-o', required=True, help='输出文档路径（.docx）')
    
    args = parser.parse_args()
    
    if not os.path.exists(args.source):
        print(f"❌ 错误：源文件不存在：{args.source}", file=sys.stderr)
        sys.exit(1)
    
    if not os.path.exists(args.template):
        print(f"❌ 错误：模板文件不存在：{args.template}", file=sys.stderr)
        sys.exit(1)
    
    md_bridge(args.source, args.template, args.output)


if __name__ == '__main__':
    main()
