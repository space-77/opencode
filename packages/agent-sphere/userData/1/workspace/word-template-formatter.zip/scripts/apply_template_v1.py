#!/usr/bin/env python3
"""
Word Template Formatter — 将任意 Word 文档转换为模板格式的 Word 文档。

核心策略：
  1. 以模板为基础创建输出文档（保留页面设置、样式、封面、目录结构）
  2. 遍历源文档 body 子元素（保持段落与表格的原始顺序）
  3. 将内容映射到模板样式：标题 → Heading，正文 → Normal，题注 → Caption 等
  4. 图片完整复制（含 image part 和 relationship），公式保留 OMML
  5. 表格复制并应用模板 Table Grid 样式

用法：
  python3 apply_template.py --source <源文件.docx> --template <模板文件.docx> --output <输出文件.docx>
"""

import argparse
import copy
import os
import re
import sys
from io import BytesIO
from typing import Optional, Tuple, List, Dict

from docx import Document
from docx.shared import Pt, Cm, Emu, Twips
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from lxml import etree


# ────────────────────────────────────────────────────────────────────────────
# 1. 通用辅助
# ────────────────────────────────────────────────────────────────────────────

def emu_to_pt(emu: Optional[int]) -> Optional[float]:
    return round(emu / 12700, 1) if emu else None

def twips_to_pt(twips: Optional[int]) -> Optional[float]:
    return round(twips / 20, 1) if twips else None


def _has_namespace_prefix(tag: str) -> bool:
    """判断 XML tag 是否包含 namespace 前缀。"""
    return '}' in tag or ':' in tag


def _get_tag_local_name(tag: str) -> str:
    """获取 XML tag 的本地名。"""
    if '}' in tag:
        return tag.split('}')[-1]
    if ':' in tag:
        return tag.split(':')[-1]
    return tag


# ────────────────────────────────────────────────────────────────────────────
# 2. 图片复制（含 relationship）
# ────────────────────────────────────────────────────────────────────────────

def copy_image_parts(source_doc, target_doc, source_drawing, target_drawing):
    """
    复制源 drawing 中的图片到新文档，包括 image part 和 relationship。
    使用 python-docx 的 OPC 包管理来正确注册图片 part。
    """
    from docx.opc.package import OpcPackage
    from docx.opc.part import Part
    from docx.opc.packuri import PackURI
    
    blip_ns = 'http://schemas.openxmlformats.org/drawingml/2006/main'
    rel_ns = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
    blip_els = source_drawing.findall('.//{%s}blip' % blip_ns)
    
    for blip in blip_els:
        embed_attr = blip.get('{%s}embed' % rel_ns)
        if not embed_attr:
            continue
        
        # 获取源图片 part
        try:
            src_rel = source_doc.part.rels[embed_attr]
            image_part = src_rel.target_part
            image_data = image_part.blob
            content_type = image_part.content_type
            partname = image_part.partname
        except (KeyError, AttributeError):
            continue
        
        # 检查目标文档是否已有同名 part
        existing_part = None
        for part in target_doc.part.package.parts:
            if part.partname == partname:
                existing_part = part
                break
        
        if existing_part is not None:
            # 使用已有的 part，创建新的 relationship
            try:
                new_rel = target_doc.part.relate_to(existing_part, RT.IMAGE)
                blip.set('{%s}embed' % rel_ns, new_rel.rId)
            except Exception:
                pass
        else:
            # 创建新的 image part
            try:
                new_part = Part(partname, content_type, image_data, target_doc.part.package)
                target_doc.part.package.parts.append(new_part)
                
                # 创建 relationship
                new_rel = target_doc.part.relate_to(new_part, RT.IMAGE)
                blip.set('{%s}embed' % rel_ns, new_rel.rId)
            except Exception as e:
                # 如果失败，尝试备用方案
                try:
                    # 直接添加图片到文档
                    image_stream = BytesIO(image_data)
                    new_rId = target_doc.part.get_or_add_image_part(image_stream).rId
                    blip.set('{%s}embed' % rel_ns, new_rId)
                except Exception:
                    pass


# ────────────────────────────────────────────────────────────────────────────
# 3. 段落/Run 复制（保留特殊元素：图片、公式、书签）
# ────────────────────────────────────────────────────────────────────────────

def copy_runs(source_para, target_para, source_doc, target_doc):
    """
    复制源段落的所有 runs 到目标段落，保留内容，但字体使用模板样式定义。
    只保留语义格式（bold, italic, color, underline, highlight），
    不复制字体名称和大小，让模板样式决定。
    """
    for source_run in source_para.runs:
        text = source_run.text
        new_run = target_para.add_run(text)
        
        # 只复制语义格式，不复制字体名称和大小
        if source_run.font:
            sf = source_run.font
            nf = new_run.font
            # 保留语义格式
            if sf.bold is not None:       nf.bold = sf.bold
            if sf.italic is not None:     nf.italic = sf.italic
            if sf.color and sf.color.rgb: nf.color.rgb = sf.color.rgb
            if sf.underline is not None:  nf.underline = sf.underline
            if sf.highlight_color is not None:
                nf.highlight_color = sf.highlight_color
            # 不复制 sf.name 和 sf.size —— 让模板样式决定
        
        # 复制 XML 子元素（图片、公式、书签等）
        source_r_el = source_run._r
        target_r_el = new_run._r
        
        for child in source_r_el:
            tag = child.tag
            local_name = _get_tag_local_name(tag)
            
            if local_name == 't':
                continue  # 文本元素已在 add_run 中处理
            elif local_name in ('br', 'tab', 'bookmarkStart', 'bookmarkEnd', 'rPr'):
                target_r_el.append(copy.deepcopy(child))
            elif local_name == 'drawing':
                new_drawing = copy.deepcopy(child)
                copy_image_parts(source_doc, target_doc, child, new_drawing)
                target_r_el.append(new_drawing)
            elif local_name in ('oMath', 'oMathPara'):
                target_r_el.append(copy.deepcopy(child))
            else:
                target_r_el.append(copy.deepcopy(child))


def copy_paragraph(source_para, target_doc, target_style: Optional[str] = None,
                   source_doc=None, target_doc_ref=None):
    """
    复制一个段落到目标文档，保留格式和特殊元素。
    """
    if target_style:
        new_para = target_doc.add_paragraph(style=target_style)
    else:
        new_para = target_doc.add_paragraph()
    
    # 复制段落对齐（如果模板样式未覆盖）
    if source_para.alignment is not None:
        new_para.alignment = source_para.alignment
    
    # 复制段落格式属性（如缩进、间距等）
    if source_para.paragraph_format:
        spf = source_para.paragraph_format
        npf = new_para.paragraph_format
        # 如果模板样式有明确的首行缩进，优先使用模板的
        # 否则保留源文档的
    
    # 复制 runs
    copy_runs(source_para, new_para, source_doc or target_doc, target_doc_ref or target_doc)
    
    return new_para


# ────────────────────────────────────────────────────────────────────────────
# 4. 表格复制
# ────────────────────────────────────────────────────────────────────────────

def copy_table(source_table, target_doc, source_doc=None, target_doc_ref=None):
    """
    复制表格到目标文档，保留格式、内容、图片和公式。
    改进：正确处理合并单元格、表格属性、行高等。
    """
    rows = len(source_table.rows)
    cols = len(source_table.columns)
    
    new_table = target_doc.add_table(rows=rows, cols=cols)
    
    # 尝试应用模板表格样式（如果模板有 Table Grid 样式）
    try:
        new_table.style = 'Table Grid'
    except Exception:
        pass
    
    # 复制表格属性（如对齐、自动调整等）
    if source_table.alignment is not None:
        new_table.alignment = source_table.alignment
    
    # 复制表格 XML 属性（宽度、边框、行高、单元格合并等）
    try:
        source_tbl = source_table._tbl
        target_tbl = new_table._tbl
        
        # 复制整个 tblPr（表格属性）
        source_tblPr = source_tbl.find(qn('w:tblPr'))
        if source_tblPr is not None:
            target_tblPr = target_tbl.find(qn('w:tblPr'))
            if target_tblPr is not None:
                # 复制边框
                borders = source_tblPr.find(qn('w:tblBorders'))
                if borders is not None:
                    existing_borders = target_tblPr.find(qn('w:tblBorders'))
                    if existing_borders is not None:
                        target_tblPr.remove(existing_borders)
                    target_tblPr.append(copy.deepcopy(borders))
                
                # 复制单元格间距
                cell_mar = source_tblPr.find(qn('w:tblCellMar'))
                if cell_mar is not None:
                    existing_cell_mar = target_tblPr.find(qn('w:tblCellMar'))
                    if existing_cell_mar is not None:
                        target_tblPr.remove(existing_cell_mar)
                    target_tblPr.append(copy.deepcopy(cell_mar))
                
                # 复制表格宽度
                tbl_w = source_tblPr.find(qn('w:tblW'))
                if tbl_w is not None:
                    existing_tbl_w = target_tblPr.find(qn('w:tblW'))
                    if existing_tbl_w is not None:
                        target_tblPr.remove(existing_tbl_w)
                    target_tblPr.append(copy.deepcopy(tbl_w))
                
                # 复制布局（自动调整）
                tbl_layout = source_tblPr.find(qn('w:tblLayout'))
                if tbl_layout is not None:
                    existing_layout = target_tblPr.find(qn('w:tblLayout'))
                    if existing_layout is not None:
                        target_tblPr.remove(existing_layout)
                    target_tblPr.append(copy.deepcopy(tbl_layout))
                
                # 复制对齐
                jc = source_tblPr.find(qn('w:jc'))
                if jc is not None:
                    existing_jc = target_tblPr.find(qn('w:jc'))
                    if existing_jc is not None:
                        target_tblPr.remove(existing_jc)
                    target_tblPr.append(copy.deepcopy(jc))
    except Exception:
        pass
    
    # 复制行属性（行高）
    try:
        source_tbl = source_table._tbl
        target_tbl = new_table._tbl
        source_trs = source_tbl.findall(qn('w:tr'))
        target_trs = target_tbl.findall(qn('w:tr'))
        for i, (src_tr, tgt_tr) in enumerate(zip(source_trs, target_trs)):
            src_trPr = src_tr.find(qn('w:trPr'))
            if src_trPr is not None:
                tgt_trPr = tgt_tr.find(qn('w:trPr'))
                if tgt_trPr is None:
                    tgt_trPr = parse_xml(f'<w:trPr {nsdecls("w")}></w:trPr>')
                    tgt_tr.insert(0, tgt_trPr)
                # 复制 trHeight
                trHeight = src_trPr.find(qn('w:trHeight'))
                if trHeight is not None:
                    existing = tgt_trPr.find(qn('w:trHeight'))
                    if existing is not None:
                        tgt_trPr.remove(existing)
                    tgt_trPr.append(copy.deepcopy(trHeight))
    except Exception:
        pass
    
    # 复制单元格
    for i, source_row in enumerate(source_table.rows):
        for j, source_cell in enumerate(source_row.cells):
            if i < len(new_table.rows) and j < len(new_table.rows[i].cells):
                target_cell = new_table.rows[i].cells[j]
                
                # 清空目标单元格的默认段落
                target_cell.paragraphs[0].clear()
                
                # 复制单元格段落
                for p_idx, source_para in enumerate(source_cell.paragraphs):
                    if p_idx == 0:
                        target_para = target_cell.paragraphs[0]
                    else:
                        target_para = target_cell.add_paragraph()
                    
                    # 复制段落样式
                    if source_para.style:
                        try:
                            target_para.style = source_para.style
                        except Exception:
                            pass
                    
                    if source_para.alignment is not None:
                        target_para.alignment = source_para.alignment
                    
                    # 复制 runs（含图片、公式）
                    copy_runs(source_para, target_para, source_doc or target_doc, target_doc_ref or target_doc)
                
                # 复制单元格属性（宽度、背景色、垂直对齐、合并等）
                try:
                    source_tc = source_cell._tc
                    target_tc = target_cell._tc
                    source_tcPr = source_tc.find(qn('w:tcPr'))
                    if source_tcPr is not None:
                        target_tcPr = target_tc.find(qn('w:tcPr'))
                        if target_tcPr is None:
                            target_tcPr = parse_xml(f'<w:tcPr {nsdecls("w")}></w:tcPr>')
                            target_tc.insert(0, target_tcPr)
                        
                        # 复制所有关键属性
                        for prop_name in ['w:shd', 'w:tcW', 'w:vAlign', 'w:gridSpan', 'w:vMerge']:
                            prop = source_tcPr.find(qn(prop_name))
                            if prop is not None:
                                existing = target_tcPr.find(qn(prop_name))
                                if existing is not None:
                                    target_tcPr.remove(existing)
                                target_tcPr.append(copy.deepcopy(prop))
                except Exception:
                    pass
    
    return new_table


# ────────────────────────────────────────────────────────────────────────────
# 5. 内容类型识别
# ────────────────────────────────────────────────────────────────────────────

def identify_heading(para) -> Tuple[bool, int, Optional[str]]:
    """
    判断段落是否为标题，返回 (is_heading, level, original_style_name)。
    level: 1-9，0 表示不是标题。
    """
    style_name = para.style.name if para.style else ""
    text = para.text.strip()
    
    # 1. 通过样式名识别标准 Heading 1-9
    m = re.match(r'^Heading\s*(\d+)$', style_name, re.IGNORECASE)
    if m:
        return True, int(m.group(1)), style_name
    
    # 2. 通过样式名识别中文标题 1-9
    m = re.match(r'^标题\s*(\d+)$', style_name, re.IGNORECASE)
    if m:
        return True, int(m.group(1)), style_name
    
    # 3. 通过样式名识别其他标题变体
    if re.search(r'heading|标题|h\d', style_name, re.IGNORECASE):
        m = re.search(r'(\d+)', style_name)
        if m:
            lvl = int(m.group(1))
            if 1 <= lvl <= 9:
                return True, lvl, style_name
    
    # 4. 通过文本编号特征识别（如 "1. xxx", "1.1 xxx", "1.1.1 xxx"）
    if text:
        m = re.match(r'^(\d+(?:\.\d+)*)\s+(\S+)', text)
        if m:
            parts = m.group(1).split('.')
            lvl = len(parts)
            if 1 <= lvl <= 9:
                # 额外验证：如果段落后是更长的正文，且整体格式像标题
                return True, lvl, f"Heading {lvl}"
        
        # 5. 通过中文编号识别（如 "一、", "（一）", "1."）
        cn_chapter = re.match(r'^第[一二三四五六七八九十]+章', text)
        if cn_chapter:
            return True, 1, "Heading 1"
    
    return False, 0, None


def identify_caption(para) -> Tuple[bool, str]:
    """
    判断段落是否为题注，返回 (is_caption, label_type)。
    label_type: "图" 或 "表" 或 ""。
    """
    text = para.text.strip()
    if not text:
        return False, ""
    
    style_name = para.style.name if para.style else ""
    
    # 1. 通过文本前缀识别
    if re.match(r'^图\s*\d+[-\.]?\d*', text):
        return True, "图"
    if re.match(r'^表\s*\d+[-\.]?\d*', text):
        return True, "表"
    
    # 2. 通过样式名识别
    if 'Caption' in style_name or '题注' in style_name or 'caption' in style_name.lower():
        if '图' in text or 'fig' in text.lower():
            return True, "图"
        elif '表' in text or 'table' in text.lower():
            return True, "表"
        return True, ""
    
    return False, ""


def identify_formula(para) -> bool:
    """判断段落是否为公式。
    
    检查三种方式：
    1. 段落样式名包含"公式"或"formula"
    2. run 中包含 OMML（m:oMath / m:oMathPara）
    3. 段落直接包含 OMML（m:oMath 可能作为 w:p 的子元素，不在 w:r 中）
    """
    style_name = para.style.name if para.style else ""
    if '公式' in style_name or 'formula' in style_name.lower():
        return True
    
    # 检查 runs 中的 OMML
    for run in para.runs:
        if run._r.findall(qn('m:oMath')) or run._r.findall(qn('m:oMathPara')):
            return True
    
    # 检查段落级别的 OMML（m:oMath 可能在 w:p 下，不在 w:r 中）
    p = para._p
    if p.findall(qn('m:oMath')) or p.findall(qn('m:oMathPara')):
        return True
    
    return False


def identify_image(para) -> bool:
    """判断段落是否包含图片。"""
    style_name = para.style.name if para.style else ""
    if style_name in ('图', 'Figure', 'Figure Caption') and 'Caption' not in style_name:
        return True
    
    for run in para.runs:
        if run._r.findall(qn('w:drawing')):
            return True
    return False


def identify_toc(para) -> bool:
    """判断段落是否为目录条目（由 Word 自动生成的 TOC 字段）或目录分页项。"""
    # 检查是否包含 TOC 字段
    for run in para.runs:
        for fldChar in run._r.findall(qn('w:fldChar')):
            fldCharType = fldChar.get(qn('w:fldCharType'))
            if fldCharType in ('begin', 'separate', 'end'):
                return True
        for instrText in run._r.findall(qn('w:instrText')):
            if instrText.text and 'TOC' in instrText.text:
                return True
    
    # 检查段落属性中是否包含 TOC 字段（TOC 条目可能在段落级别）
    p = para._p
    for fldChar in p.findall(qn('w:fldChar')):
        fldCharType = fldChar.get(qn('w:fldCharType'))
        if fldCharType in ('begin', 'separate', 'end'):
            return True
    for instrText in p.findall(qn('w:instrText')):
        if instrText.text and 'TOC' in instrText.text:
            return True
    
    # 检查段落样式是否明确是 TOC 样式
    style_name = para.style.name if para.style else ""
    if 'TOC' in style_name or 'toc' in style_name.lower():
        return True
    
    # 检查是否包含 TOC 超链接字段（目录条目通常包含 HYPERLINK 字段）
    text = para.text.strip()
    if text and '\t' in text:
        # 目录条目通常包含制表符和页码
        # 检查是否有类似 "1.1 标题\t\t5" 的格式
        if re.match(r'^(\d+(?:\.\d+)*)\s+\S+.*\t+\d+$', text):
            return True
    
    return False


# ────────────────────────────────────────────────────────────────────────────
# 6. 模板处理：保留封面、目录结构，清空正文占位
# ────────────────────────────────────────────────────────────────────────────

def split_template_elements(doc) -> Tuple[List, List, List, List, List]:
    """
    将模板文档的元素按节分割：
    返回 (cover_elements, toc_elements, fig_list_elements, table_list_elements, body_elements)
    
    每个元素是 (element_type, element) 元组，element_type 为 'p'（段落）或 't'（表格）。
    """
    body = doc.element.body
    children = list(body)
    
    sections = doc.sections
    # 收集每个 section break 的位置（sectPr 元素）
    sectPr_positions = []
    for i, child in enumerate(children):
        if _get_tag_local_name(child.tag) == 'sectPr':
            sectPr_positions.append(i)
    
    # 节映射：5 个 sectPr 对应 5 个节
    # 第 0 个 sectPr 是 Section 0 的结束（封面结束）
    # 第 1 个 sectPr 是 Section 1 的结束（目录结束）
    # ...
    
    cover_elements = []
    toc_elements = []
    fig_list_elements = []
    table_list_elements = []
    body_elements = []
    
    current_section = 0
    for i, child in enumerate(children):
        local_name = _get_tag_local_name(child.tag)
        
        if local_name == 'sectPr':
            current_section += 1
            continue
        
        if local_name not in ('p', 'tbl'):
            continue
        
        if current_section == 0:
            cover_elements.append((local_name, child))
        elif current_section == 1:
            toc_elements.append((local_name, child))
        elif current_section == 2:
            fig_list_elements.append((local_name, child))
        elif current_section == 3:
            table_list_elements.append((local_name, child))
        else:
            body_elements.append((local_name, child))
    
    return cover_elements, toc_elements, fig_list_elements, table_list_elements, body_elements


def remove_body_placeholders(doc):
    """
    移除模板目录节、图目录节、表目录节和正文节中的所有占位内容。
    保留封面、目录标题、图目录标题、表目录标题的完整结构。
    
    注意：此模板中的 section break 嵌套在段落属性（pPr/sectPr）中。
    """
    body = doc.element.body
    children = list(body)
    
    # 找到所有包含 sectPr 的段落索引（section break 段落）
    section_break_indices = []
    for i, child in enumerate(children):
        tag = _get_tag_local_name(child.tag)
        if tag == 'p':
            pPr = child.find(qn('w:pPr'))
            if pPr is not None:
                sectPr = pPr.find(qn('w:sectPr'))
                if sectPr is not None:
                    section_break_indices.append(i)
    
    # 找到末尾的 body sectPr 索引
    last_sectPr_idx = None
    for i in range(len(children) - 1, -1, -1):
        if _get_tag_local_name(children[i].tag) == 'sectPr':
            last_sectPr_idx = i
            break
    
    # 定义各节的范围
    if len(section_break_indices) >= 4:
        # 5个节
        cover_end = section_break_indices[0]      # 封面结束 = Section 1 开始
        toc_end = section_break_indices[1]          # 目录结束 = Section 2 开始
        fig_list_end = section_break_indices[2]     # 图目录结束 = Section 3 开始
        table_list_end = section_break_indices[3]   # 表目录结束 = Section 4 开始
        body_end = last_sectPr_idx if last_sectPr_idx is not None else len(children)
    elif len(section_break_indices) >= 1:
        cover_end = section_break_indices[0]
        toc_end = section_break_indices[0]
        fig_list_end = section_break_indices[-1]
        table_list_end = section_break_indices[-1]
        body_end = last_sectPr_idx if last_sectPr_idx is not None else len(children)
    else:
        cover_end = last_sectPr_idx if last_sectPr_idx is not None else len(children)
        toc_end = cover_end
        fig_list_end = cover_end
        table_list_end = cover_end
        body_end = cover_end
    
    def _clear_section_content(start_idx, end_idx, keep_first_heading=False):
        """清空指定节中的内容，可选保留第一个标题段落。"""
        to_remove = []
        first_kept = False
        for i in range(start_idx, end_idx):
            child = children[i]
            tag = _get_tag_local_name(child.tag)
            if tag == 'p':
                # 检查是否是 section break 段落
                pPr = child.find(qn('w:pPr'))
                if pPr is not None and pPr.find(qn('w:sectPr')) is not None:
                    # 保留段落，但清空所有非 pPr 内容
                    for sub in list(child):
                        sub_tag = _get_tag_local_name(sub.tag)
                        if sub_tag != 'pPr':
                            child.remove(sub)
                    continue
                
                # 如果要求保留第一个标题，检查是否是标题段落
                if keep_first_heading and not first_kept:
                    # 检查段落样式
                    pStyle = child.find(qn('w:pStyle'))
                    style_val = None
                    if pStyle is not None:
                        style_val = pStyle.get(qn('w:val'))
                    
                    # 获取文本
                    text_runs = child.findall('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t')
                    text = ''.join([r.text for r in text_runs if r.text]).strip()
                    
                    # 判断是否是标题（Heading 1 或包含 "目录" / "图目录" / "表目录"）
                    is_heading = False
                    if style_val and re.match(r'^(Heading\s*1|标题\s*1)', style_val, re.IGNORECASE):
                        is_heading = True
                    if text in ('目  录', '图目录', '表目录'):
                        is_heading = True
                    
                    if is_heading:
                        first_kept = True
                        # 保留此段落，但清空非标题文本的内容（如果段落中有 TOC 字段等）
                        # 实际上，对于标题段落，保留其内容即可
                        # 如果标题段落中有其他内容（如 TOC 字段），可能需要清空
                        # 这里保留段落，跳过不删除
                        continue
                
                # 如果保留标题，只删除非标题段落
                if keep_first_heading and first_kept:
                    # 删除所有后续段落（TOC 条目、空段落等）
                    to_remove.append(child)
                else:
                    to_remove.append(child)
            elif tag == 'tbl':
                to_remove.append(child)
        
        for child in to_remove:
            body.remove(child)
    
    # 清空目录节（保留标题）
    _clear_section_content(cover_end, toc_end, keep_first_heading=True)
    # 清空图目录节（保留标题）
    _clear_section_content(toc_end, fig_list_end, keep_first_heading=True)
    # 清空表目录节（保留标题）
    _clear_section_content(fig_list_end, table_list_end, keep_first_heading=True)
    # 清空正文节
    _clear_section_content(table_list_end, body_end, keep_first_heading=False)
    
    # 清空正文节页眉（如果有占位符）
    if len(doc.sections) > 4:
        body_section = doc.sections[4]
        header = body_section.header
        if header and header.paragraphs:
            for p in header.paragraphs:
                if p.text.strip():
                    # 清空页眉段落内容，保留结构
                    p.clear()
    
    # 返回各节的范围，供后续使用
    return {
        'cover_end': cover_end,
        'toc_end': toc_end,
        'fig_list_end': fig_list_end,
        'table_list_end': table_list_end,
        'body_end': body_end,
    }


# ────────────────────────────────────────────────────────────────────────────
# 7. 主转换流程
# ────────────────────────────────────────────────────────────────────────────

def apply_template(source_path: str, template_path: str, output_path: str):
    """将源文档转换为模板格式。"""
    
    # 1. 读取文档
    source_doc = Document(source_path)
    template_doc = Document(template_path)
    
    # 2. 创建输出文档（基于模板）
    output_doc = Document(template_path)
    
    # 3. 移除模板正文节中的占位内容
    remove_body_placeholders(output_doc)
    
    # 4. 遍历源文档 body 子元素，保持段落和表格的顺序
    source_body = source_doc.element.body
    source_children = list(source_body)
    
    # 样式映射
    heading_map = {i: f'Heading {i}' for i in range(1, 10)}
    
    # 统计信息
    stats = {
        'headings': 0,
        'paragraphs': 0,
        'tables': 0,
        'images': 0,
        'captions': 0,
        'formulas': 0,
        'empty': 0,
    }
    
    # 收集目录信息
    headings_for_toc = []
    figures_for_toc = []
    tables_for_toc = []
    
    # 收集连续空段落信息，用于合并处理
    empty_para_threshold = 5  # 超过此数量的连续空段落将被压缩
    consecutive_empty = 0
    
    for child in source_children:
        local_name = _get_tag_local_name(child.tag)
        
        if local_name == 'p':
            # 段落
            para = None
            for p in source_doc.paragraphs:
                if p._p is child:
                    para = p
                    break
            if para is None:
                continue
            
            text = para.text.strip()
            
            # 检查是否包含分页/分节导致的空段落
            # 如果连续空段落过多，进行压缩
            if not text:
                consecutive_empty += 1
                if consecutive_empty > empty_para_threshold:
                    # 跳过这个空段落，不添加
                    continue
            else:
                consecutive_empty = 0
            
            # 识别段落类型
            is_hd, level, hd_style = identify_heading(para)
            if is_hd:
                target_style = heading_map.get(level, 'Heading 1')
                copy_paragraph(para, output_doc, target_style, source_doc, output_doc)
                stats['headings'] += 1
                headings_for_toc.append((level, text))
                continue
            
            is_cap, cap_label = identify_caption(para)
            if is_cap:
                copy_paragraph(para, output_doc, 'Caption', source_doc, output_doc)
                stats['captions'] += 1
                if cap_label == '图':
                    figures_for_toc.append(text)
                elif cap_label == '表':
                    tables_for_toc.append(text)
                continue
            
            if identify_formula(para):
                copy_paragraph(para, output_doc, '公式', source_doc, output_doc)
                stats['formulas'] += 1
                continue
            
            if identify_image(para):
                copy_paragraph(para, output_doc, '图', source_doc, output_doc)
                stats['images'] += 1
                continue
            
            if identify_toc(para):
                # 跳过源文档中的 TOC 条目（这些会由模板自动生成）
                continue
            
            # 普通段落
            if not text:
                # 空段落 - 添加一个空段落作为分隔
                output_doc.add_paragraph()
                stats['empty'] += 1
            else:
                copy_paragraph(para, output_doc, 'Normal', source_doc, output_doc)
                stats['paragraphs'] += 1
        
        elif local_name == 'tbl':
            # 表格
            # 重置连续空段落计数（表格不算空段落）
            consecutive_empty = 0
            table = None
            for t in source_doc.tables:
                if t._tbl is child:
                    table = t
                    break
            if table is not None:
                copy_table(table, output_doc, source_doc, output_doc)
                stats['tables'] += 1
    
    # 5. 应用模板正文节（最后一节）的页面设置到所有节
    # 模板通常有多个节：封面/目录/图目录/表目录/正文，正文节是最后一个
    template_body_section = template_doc.sections[-1]
    for section in output_doc.sections:
        section.page_width = template_body_section.page_width
        section.page_height = template_body_section.page_height
        section.top_margin = template_body_section.top_margin
        section.bottom_margin = template_body_section.bottom_margin
        section.left_margin = template_body_section.left_margin
        section.right_margin = template_body_section.right_margin
        section.header_distance = template_body_section.header_distance
        section.footer_distance = template_body_section.footer_distance
        section.gutter = template_body_section.gutter
    
    # 6. 保存
    output_doc.save(output_path)
    
    # 7. 输出统计
    print(f"✅ 转换完成：{output_path}")
    print(f"   标题：{stats['headings']} 个")
    print(f"   正文段落：{stats['paragraphs']} 个")
    print(f"   表格：{stats['tables']} 个")
    print(f"   图片：{stats['images']} 个")
    print(f"   题注：{stats['captions']} 个")
    print(f"   公式：{stats['formulas']} 个")
    print(f"   空段落：{stats['empty']} 个")
    print(f"   目录条目：{len(headings_for_toc)} 个标题")
    print(f"   图目录条目：{len(figures_for_toc)} 个")
    print(f"   表目录条目：{len(tables_for_toc)} 个")
    print()
    print("⚠️  注意：")
    print("   1. 目录（TOC）字段在 Word 中打开后需按 F9 更新")
    print("   2. 图目录和表目录需手动更新或在 Word 中右键更新域")
    print("   3. 封面页信息（项目名称、编号、日期等）需手动填写")


def discover_templates():
    """
    扫描 assets/ 目录，发现所有可用模板文件。
    优先检查脚本同级目录下的 assets/，其次检查当前工作目录。
    """
    script_dir = os.path.dirname(os.path.abspath(__file__))
    skill_dir = os.path.dirname(script_dir)  # scripts/ 的上一级是 skill 根目录
    assets_dir = os.path.join(skill_dir, 'assets')
    
    templates = []
    
    # 扫描 skill 根目录下的 assets/
    if os.path.isdir(assets_dir):
        for f in sorted(os.listdir(assets_dir)):
            if f.endswith('.docx'):
                templates.append({
                    'name': f,
                    'path': os.path.join(assets_dir, f)
                })
    
    # 如果当前工作目录下也有 templates/ 或 assets/，也扫描
    for scan_dir in ['templates', 'assets']:
        if os.path.isdir(scan_dir):
            for f in sorted(os.listdir(scan_dir)):
                if f.endswith('.docx'):
                    path = os.path.join(scan_dir, f)
                    # 去重
                    if not any(t['path'] == path for t in templates):
                        templates.append({'name': f, 'path': path})
    
    return templates


def interactive_select_template():
    """交互式选择模板。"""
    templates = discover_templates()
    
    if not templates:
        print("❌ 错误：未找到任何 .docx 模板文件。", file=sys.stderr)
        print("   请将模板文件放入 skill 的 assets/ 目录，或指定 --template 路径。", file=sys.stderr)
        sys.exit(1)
    
    if len(templates) == 1:
        t = templates[0]
        print(f"📄 发现唯一模板：{t['name']}")
        confirm = input("是否使用此模板？ [Y/n]：").strip().lower()
        if confirm in ('', 'y', 'yes'):
            return t['path']
        else:
            print("已取消。")
            sys.exit(0)
    
    print("📁 发现多个模板，请选择：")
    for i, t in enumerate(templates, 1):
        print(f"  {i}. {t['name']}")
    
    while True:
        choice = input("\n输入编号（或按 0 取消）：").strip()
        if choice == '0':
            print("已取消。")
            sys.exit(0)
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(templates):
                return templates[idx]['path']
            else:
                print(f"❌ 无效编号，请输入 1-{len(templates)} 之间的数字。")
        except ValueError:
            print("❌ 请输入数字。")


# ────────────────────────────────────────────────────────────────────────────
# 8. 命令行入口
# ────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description='将 Word 文档严格转换为模板格式的 Word 文档。'
    )
    parser.add_argument('--source', '-s', required=True, help='源文档路径（.docx）')
    parser.add_argument('--template', '-t', help='模板文档路径（.docx），不指定则进入交互选择')
    parser.add_argument('--output', '-o', required=True, help='输出文档路径（.docx）')
    parser.add_argument('--interactive', '-i', action='store_true',
                        help='强制进入交互模式选择模板（即使指定了 --template 也忽略）')
    
    args = parser.parse_args()
    
    if not os.path.exists(args.source):
        print(f"❌ 错误：源文件不存在：{args.source}", file=sys.stderr)
        sys.exit(1)
    
    # 确定模板路径
    template_path = args.template
    if args.interactive or not template_path:
        template_path = interactive_select_template()
    
    if not os.path.exists(template_path):
        print(f"❌ 错误：模板文件不存在：{template_path}", file=sys.stderr)
        sys.exit(1)
    
    apply_template(args.source, template_path, args.output)


if __name__ == '__main__':
    main()
